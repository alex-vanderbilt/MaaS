# DO NOT COMMIT THIS

twilio_account_sid = 'AC0c81667e6862decf3a56bb115a214b56'

twilio_auth_token = '8a97146688cdd62c3958909207b2e642'