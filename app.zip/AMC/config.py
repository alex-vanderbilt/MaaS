# DO NOT COMMIT THIS

api_secret = "357FD3CC-0DE5-402A-A169-D4EC3EE2B0D4"

database_secret_key = "4ICQcRSBXWUywiEzbi5ymuJvQ0OqmKOt"